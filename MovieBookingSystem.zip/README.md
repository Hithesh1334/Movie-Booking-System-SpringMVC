# Movie-Booking-System-SpringMVC

------
* Database: Mysql
* Frontend: Html
* Backend: java
* Architecture : MVC
* Framework : Spring


This project Includes
1. Login 
2. Register
3. View movies
4. Book movie
5. Make Payment
6. Cancle booking

* UI 
1. 
![Images\UI1.png](https://github.com/Hithesh1334/Movie-Booking-System-SpringMVC/blob/master/Images/UI1.png)
----
2. 
<<<<<<< HEAD
![alt text](Images\UI2.png)

-----
* Database: MYSQL
=======
![Images\UI2.png](https://github.com/Hithesh1334/Movie-Booking-System-SpringMVC/blob/master/Images/UI2.png)
>>>>>>> 783a9fbb42af6dfd9e363fe692d49d7ae7a0bc07
